const mongoose = require("mongoose");

const driverSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true }, // e.g. "D001" — human-readable ID used in the UI
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true }, // real phone number, used for SMS
    licence: { type: String, required: true, trim: true },
    status: { type: String, enum: ["Available", "Assigned", "Off Duty"], default: "Available" },
    image: { type: String, default: null }, // base64 photo
  },
  { timestamps: true }
);

module.exports = mongoose.model("Driver", driverSchema);
