const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

// POST /api/send-email — sends a real email as a backup notification channel.
// Body: { to: "someone@example.com", subject: "...", message: "..." }
//
// Uses your own Gmail account via an "app password" — no domain to buy or
// verify (unlike most email APIs), just one security setting turned on in
// your existing Google account. See README for the 2-minute setup.
router.post("/", async (req, res) => {
  try {
    const { to, subject, message } = req.body;

    if (!to || !message) {
      return res.status(400).json({ error: "to and message are required" });
    }

    if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
      return res.status(500).json({
        error: "Email isn't configured yet. Add GMAIL_USER and GMAIL_APP_PASSWORD to backend/.env — see README.",
      });
    }

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    await transporter.sendMail({
      from: `"Roadrunner Couriers" <${process.env.GMAIL_USER}>`,
      to,
      subject: subject || "Delivery update — Roadrunner Couriers",
      text: message,
    });

    res.json({ success: true });
  } catch (err) {
    console.error("Email send failed:", err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
