const express = require("express");
const router = express.Router();

// POST /api/send-sms — sends a REAL text message via ClickSend.
// Body: { to: "+61412345678", message: "..." }
//
// ClickSend is an Australian SMS provider — sign up free at
// dashboard.clicksend.com/signup (no credit card needed), and you get free
// trial credit automatically. Your credentials live only here on the
// server, never in the frontend.
router.post("/", async (req, res) => {
  try {
    const { to, message } = req.body;

    if (!to || !message) {
      return res.status(400).json({ error: "to and message are required" });
    }

    if (!process.env.CLICKSEND_USERNAME || !process.env.CLICKSEND_API_KEY) {
      return res.status(500).json({
        error: "ClickSend isn't configured yet. Add CLICKSEND_USERNAME and CLICKSEND_API_KEY to backend/.env — see README.",
      });
    }

    const auth = Buffer.from(
      `${process.env.CLICKSEND_USERNAME}:${process.env.CLICKSEND_API_KEY}`
    ).toString("base64");

    const response = await fetch("https://rest.clicksend.com/v3/sms/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify({
        messages: [{ source: "nodejs", body: message, to }],
      }),
    });

    const data = await response.json();

    const result = data?.data?.messages?.[0];
    if (!response.ok || !result || result.status === "SMS_ERROR") {
      return res.status(500).json({
        error: result?.status || data?.response_msg || "ClickSend could not send this message",
      });
    }

    res.json({ success: true, sid: result.message_id });
  } catch (err) {
    console.error("SMS send failed:", err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
