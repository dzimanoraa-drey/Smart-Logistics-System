const express = require("express");
const Driver = require("../models/Driver");

const router = express.Router();

// GET /api/drivers — list all drivers
router.get("/", async (req, res) => {
  try {
    const drivers = await Driver.find().sort({ name: 1 });
    res.json(drivers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/drivers — register a new driver
router.post("/", async (req, res) => {
  try {
    const { name, email, phone, licence, status, image } = req.body;
    if (!name || !email || !phone || !licence) {
      return res.status(400).json({ error: "name, email, phone, and licence are required" });
    }

    const count = await Driver.countDocuments();
    const id = `D${String(count + 1).padStart(3, "0")}`;

    const driver = await Driver.create({ id, name, email, phone, licence, status, image });
    res.status(201).json(driver);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/drivers/:id — update a driver (uses Mongo _id, matching the frontend's editingDriver._id)
router.put("/:id", async (req, res) => {
  try {
    const { name, email, phone, licence, status, image } = req.body;
    const driver = await Driver.findByIdAndUpdate(
      req.params.id,
      { name, email, phone, licence, status, image },
      { new: true }
    );
    if (!driver) return res.status(404).json({ error: "Driver not found" });
    res.json(driver);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/drivers/:id
router.delete("/:id", async (req, res) => {
  try {
    const driver = await Driver.findByIdAndDelete(req.params.id);
    if (!driver) return res.status(404).json({ error: "Driver not found" });
    res.json({ message: "Driver deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
