require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config");

const driverRoutes = require("./routes/drivers");
const smsRoutes = require("./routes/sms");
const emailRoutes = require("./routes/email");

const app = express();

app.use(cors());
app.use(express.json({ limit: "8mb" })); // 8mb allows base64 driver photos

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Smart Logistics backend is running" });
});

app.use("/api/drivers", driverRoutes);
app.use("/api/send-sms", smsRoutes);
app.use("/api/send-email", emailRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Backend listening on http://localhost:${PORT}`);
  });
});
