import { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const BRISBANE_CENTER = [-27.4698, 153.0251];

async function reverseGeocode(lat, lng) {
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
    const data = await res.json();
    return data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  } catch (err) {
    return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  }
}

function ClickHandler({ active, setPickupLocation, setDeliveryLocation, setPickupAddress, setDeliveryAddress }) {
  useMapEvents({
    async click(e) {
      const { lat, lng } = e.latlng;
      const address = await reverseGeocode(lat, lng);
      if (active === "pickup") {
        setPickupLocation([lat, lng]);
        setPickupAddress(address);
      } else {
        setDeliveryLocation([lat, lng]);
        setDeliveryAddress(address);
      }
    },
  });
  return null;
}

// This fixes the "map breaks when opening the job form" bug. When a Leaflet
// map is created while its container is hidden (e.g. a modal still
// animating in, or the very first render before layout settles), Leaflet
// calculates the map's size as 0x0 and the tiles never load correctly —
// it looks broken or throws errors on interaction. Calling invalidateSize()
// once the container is actually visible fixes this.
function SizeFix() {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 150);
    return () => clearTimeout(timer);
  }, [map]);
  return null;
}

export default function MapPicker({
  active, pickupLocation, deliveryLocation,
  setPickupLocation, setDeliveryLocation,
  setPickupAddress, setDeliveryAddress,
}) {
  // A stable id generated once per mount. Passing this as the MapContainer's
  // key guarantees React creates a brand-new DOM node each time this
  // component mounts, rather than possibly reusing one Leaflet already
  // attached itself to — which is what causes the
  // "Map container is already initialized" crash when the job form is
  // closed and reopened.
  const instanceId = useRef(Math.random().toString(36).slice(2));

  return (
    <div>
      <p style={{ fontSize: "12.5px", color: "#6b7280", margin: "0 0 8px" }}>
        Click the map to set the <strong>{active === "pickup" ? "pickup" : "delivery"}</strong> location
        (click the pickup or delivery address field above first to switch which one you're placing).
      </p>
      <MapContainer
        key={instanceId.current}
        center={pickupLocation || BRISBANE_CENTER}
        zoom={12}
        style={{ height: "300px", width: "100%", borderRadius: "10px" }}
      >
        <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <SizeFix />
        <ClickHandler
          active={active}
          setPickupLocation={setPickupLocation}
          setDeliveryLocation={setDeliveryLocation}
          setPickupAddress={setPickupAddress}
          setDeliveryAddress={setDeliveryAddress}
        />
        {pickupLocation && <Marker position={pickupLocation} />}
        {deliveryLocation && <Marker position={deliveryLocation} />}
      </MapContainer>
    </div>
  );
}
